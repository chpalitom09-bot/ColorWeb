const $ = s => document.querySelector(s);
const h2r = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16));
function hsl([r, g, b]) {
  r /= 255; g /= 255; b /= 255;
  const M = Math.max(r, g, b), m = Math.min(r, g, b), l = (M + m) / 2, d = M - m;
  let h = 0, s = 0;
  if (d) { s = d / (1 - Math.abs(2 * l - 1)); h = M == r ? ((g - b) / d + 6) % 6 : M == g ? (b - r) / d + 2 : (r - g) / d + 4; h = Math.round(h * 60); }
  return [h, Math.round(s * 100), Math.round(l * 100)];
}
const vals = hex => { const c = h2r(hex), h = hsl(c); return { hex, rgb: `rgb(${c.join(', ')})`, hsl: `hsl(${h[0]}, ${h[1]}%, ${h[2]}%)` }; };
let st = { history: [], fmt: 'hex' }, tt;
const save = () => chrome.storage.local.set(st);
function toast(t) { const e = $('#toast'); e.textContent = t; e.classList.add('on'); clearTimeout(tt); tt = setTimeout(() => e.classList.remove('on'), 1100); }
async function copy(t) { try { await navigator.clipboard.writeText(t); toast('Copié'); } catch (e) { toast('Copie impossible'); } }
function render() {
  const cur = st.history[0], v = cur && vals(cur), sw = $('#sw');
  sw.classList.toggle('empty', !cur);
  if (cur) {
    const c = h2r(cur);
    sw.style.setProperty('--c', cur);
    sw.style.setProperty('--sc', (c[0] * 299 + c[1] * 587 + c[2] * 114) / 1000 > 150 ? '#14151a' : '#fff');
  }
  $('#big').textContent = cur || 'Aucune couleur';
  ['hex', 'rgb', 'hsl'].forEach(k => $('#v' + k).textContent = v ? v[k] : '—');
  document.querySelectorAll('.seg button').forEach(b => b.classList.toggle('on', b.dataset.f === st.fmt));
  const hi = $('#hist'); hi.innerHTML = '';
  if (!st.history.length) { hi.innerHTML = '<p>Vos couleurs apparaîtront ici.</p>'; }
  st.history.forEach((h, i) => {
    const b = document.createElement('button');
    b.style.background = h; b.title = h; b.setAttribute('aria-label', h);
    if (!i) b.className = 'cur';
    b.onclick = () => { st.history = [h, ...st.history.filter(x => x !== h)]; save(); render(); };
    hi.appendChild(b);
  });
}
document.querySelectorAll('.row').forEach(b => b.onclick = () => { if (st.history[0]) copy(vals(st.history[0])[b.dataset.k]); });
document.querySelectorAll('.seg button').forEach(b => b.onclick = () => { st.fmt = b.dataset.f; save(); render(); });
$('#clear').onclick = () => { st.history = []; save(); render(); };
$('#pick').onclick = async () => {
  $('#err').textContent = '';
  const r = await chrome.runtime.sendMessage({ type: 'pick' });
  if (r && r.ok) window.close();
  else $('#err').textContent = /cannot (be scripted|access)|extensions gallery|chrome:\/\//i.test((r && r.error) || '')
    ? "Cette page n'autorise pas les extensions (page système ou boutique Chrome)."
    : "Impossible de lancer la pipette sur cette page.";
};
chrome.commands.getAll(c => { const p = c.find(x => x.name === 'pick'); $('#sc').textContent = (p && p.shortcut) || ''; });
chrome.storage.local.get({ history: [], fmt: 'hex' }).then(s => { st = s; render(); });
