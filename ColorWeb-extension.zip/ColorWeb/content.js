(() => {
  if (window.__cw) return;
  window.__cw = 1;
  let on = false;
  chrome.runtime.onMessage.addListener(m => {
    if (m && m.type === 'start' && !on) {
      on = true;
      const i = new Image();
      i.onload = () => run(i);
      i.onerror = () => { on = false; };
      i.src = m.shot;
    }
  });
  const cl = (v, a, b) => Math.min(b, Math.max(a, v));
  const hx = c => '#' + c.map(v => v.toString(16).padStart(2, '0')).join('').toUpperCase();
  function hsl([r, g, b]) {
    r /= 255; g /= 255; b /= 255;
    const M = Math.max(r, g, b), m = Math.min(r, g, b), l = (M + m) / 2, d = M - m;
    let h = 0, s = 0;
    if (d) { s = d / (1 - Math.abs(2 * l - 1)); h = M == r ? ((g - b) / d + 6) % 6 : M == g ? (b - r) / d + 2 : (r - g) / d + 4; h = Math.round(h * 60); }
    return [h, Math.round(s * 100), Math.round(l * 100)];
  }
  const fmt = (c, f) => f === 'rgb' ? `rgb(${c.join(', ')})` : f === 'hsl' ? (h => `hsl(${h[0]}, ${h[1]}%, ${h[2]}%)`)(hsl(c)) : hx(c);
  async function copy(t) {
    try { await navigator.clipboard.writeText(t); }
    catch (e) { const a = document.createElement('textarea'); a.value = t; a.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(a); a.select(); document.execCommand('copy'); a.remove(); }
  }
  function run(img) {
    const cv = document.createElement('canvas');
    cv.width = img.width; cv.height = img.height;
    const cx = cv.getContext('2d', { willReadFrequently: true });
    cx.drawImage(img, 0, 0);
    const sx = img.width / innerWidth, sy = img.height / innerHeight;
    let snap = true, cur = [0, 0, 0], ready = false;
    const host = document.createElement('div');
    host.style.cssText = 'all:initial;position:fixed;inset:0;z-index:2147483647;cursor:none;display:block';
    const sh = host.attachShadow({ mode: 'closed' });
    sh.innerHTML = `<style>
      *{box-sizing:border-box}
      .r{position:fixed;width:132px;height:132px;border-radius:50%;border:3px solid #fff;overflow:hidden;box-shadow:0 12px 32px rgba(0,0,0,.5),0 0 0 1px rgba(0,0,0,.35);pointer-events:none;display:none;background:#000}
      .r canvas{width:132px;height:132px;image-rendering:pixelated;display:block}
      .r i{position:absolute;width:12px;height:12px;border:2px solid #fff;mix-blend-mode:difference}
      .t{position:fixed;display:none;pointer-events:none;font:600 13px/1 system-ui,-apple-system,"Segoe UI",sans-serif;color:#fff;background:#15161a;padding:8px 12px;border-radius:10px;box-shadow:0 8px 24px rgba(0,0,0,.45);white-space:nowrap;transform:translateX(-50%)}
      .t b{display:inline-block;width:12px;height:12px;border-radius:4px;margin-right:8px;vertical-align:-2px;border:1px solid rgba(255,255,255,.35)}
      .h{position:fixed;left:50%;bottom:22px;transform:translateX(-50%);font:500 13px/1 system-ui,-apple-system,"Segoe UI",sans-serif;color:#d5d8de;background:rgba(21,22,26,.92);padding:10px 16px;border-radius:999px;pointer-events:none;box-shadow:0 8px 24px rgba(0,0,0,.4);white-space:nowrap}
      .h kbd{font:inherit;color:#fff;background:#2d3035;border-radius:5px;padding:2px 6px;margin:0 2px}
      .ok{position:fixed;left:50%;top:28px;transform:translateX(-50%);font:600 15px/1 system-ui,-apple-system,"Segoe UI",sans-serif;color:#fff;background:#15161a;padding:13px 20px;border-radius:14px;box-shadow:0 12px 36px rgba(0,0,0,.5);display:none;align-items:center;gap:10px}
      .ok b{width:16px;height:16px;border-radius:5px;border:1px solid rgba(255,255,255,.35)}
    </style>
    <div class="r"><canvas width="11" height="11"></canvas><i></i></div>
    <div class="t"><b></b><span></span></div>
    <div class="h"><kbd>Clic</kbd> copier · <kbd>T</kbd> mode texte <span id="m">activé</span> · <kbd>Échap</kbd> annuler</div>
    <div class="ok"><b></b><span></span></div>`;
    const $ = s => sh.querySelector(s);
    const ring = $('.r'), lc = ring.querySelector('canvas').getContext('2d'), ret = ring.querySelector('i'), tag = $('.t'), ok = $('.ok');
    function sample(px, py) {
      const d = cx.getImageData(px - 3, py - 3, 7, 7).data, at = (i, j) => { const k = (j * 7 + i) * 4; return [d[k], d[k + 1], d[k + 2]]; };
      const c = at(3, 3);
      if (!snap) return { c, dx: 0, dy: 0 };
      const n = {};
      for (let j = 0; j < 7; j++) for (let i = 0; i < 7; i++) { const p = at(i, j), k = p.map(v => v >> 4).join(); (n[k] = n[k] || { n: 0, p }).n++; }
      const bg = Object.values(n).sort((a, b) => b.n - a.n)[0].p, dist = p => (p[0] - bg[0]) ** 2 + (p[1] - bg[1]) ** 2 + (p[2] - bg[2]) ** 2;
      let best = c, bd = dist(c), bx = 0, by = 0;
      for (let j = 1; j <= 5; j++) for (let i = 1; i <= 5; i++) { const p = at(i, j), dd = dist(p); if (dd > bd + 300) { bd = dd; best = p; bx = i - 3; by = j - 3; } }
      return { c: best, dx: bx, dy: by };
    }
    function move(e) {
      const px = cl(Math.round(e.clientX * sx), 5, img.width - 6), py = cl(Math.round(e.clientY * sy), 5, img.height - 6);
      const o = sample(px, py); cur = o.c; ready = true;
      lc.putImageData(cx.getImageData(px - 5, py - 5, 11, 11), 0, 0);
      ret.style.left = (5 + o.dx) * 12 + 'px'; ret.style.top = (5 + o.dy) * 12 + 'px';
      ring.style.display = 'block'; ring.style.left = e.clientX - 66 + 'px'; ring.style.top = e.clientY - 66 + 'px';
      tag.style.display = 'block'; tag.style.left = e.clientX + 'px';
      tag.style.top = (e.clientY + 150 > innerHeight ? e.clientY - 112 : e.clientY + 76) + 'px';
      tag.firstChild.style.background = hx(cur); tag.lastChild.textContent = hx(cur);
    }
    function close() { removeEventListener('keydown', key, true); host.remove(); on = false; }
    async function choose() {
      if (!ready) return;
      const { fmt: f = 'hex', history = [] } = await chrome.storage.local.get({ fmt: 'hex', history: [] });
      const text = fmt(cur, f), h = hx(cur);
      await copy(text);
      await chrome.storage.local.set({ history: [h, ...history.filter(x => x !== h)].slice(0, 24) });
      ring.style.display = tag.style.display = 'none'; $('.h').style.display = 'none';
      ok.style.display = 'flex'; ok.firstChild.style.background = h; ok.lastChild.textContent = 'Copié · ' + text;
      host.style.cursor = 'default';
      setTimeout(close, 1500);
    }
    function key(e) {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); }
      else if (e.key.toLowerCase() === 't') { snap = !snap; $('#m').textContent = snap ? 'activé' : 'désactivé'; e.stopPropagation(); }
    }
    host.addEventListener('mousemove', move);
    host.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); choose(); });
    host.addEventListener('contextmenu', e => { e.preventDefault(); close(); });
    host.addEventListener('wheel', e => e.preventDefault(), { passive: false });
    addEventListener('keydown', key, true);
    document.documentElement.appendChild(host);
  }
})();
