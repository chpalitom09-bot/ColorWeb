ColorWeb — extension Chrome (Manifest V3)

Installation (mode développeur) :
1. Décompressez ce dossier.
2. Ouvrez chrome://extensions et activez « Mode développeur ».
3. Cliquez sur « Charger l'extension non empaquetée » et choisissez ce dossier.
4. Épinglez ColorWeb dans la barre d'outils. Raccourci par défaut : Alt + Maj + C.

Utilisation : cliquez sur « Attraper une couleur », pointez, cliquez. Le code est copié.
T : mode texte (vise la vraie couleur des lettres). Échap : annuler.
Ne fonctionne pas sur les pages système (chrome://) ni sur la boutique Chrome.
