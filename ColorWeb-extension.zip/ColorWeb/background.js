async function pick(tab) {
  try {
    const shot = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
    await chrome.tabs.sendMessage(tab.id, { type: 'start', shot });
    return { ok: true };
  } catch (e) {
    return { ok: false, error: String((e && e.message) || e) };
  }
}
const activeTab = async () => (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
chrome.runtime.onMessage.addListener((m, _s, send) => {
  if (m && m.type === 'pick') { activeTab().then(pick).then(send); return true; }
});
chrome.commands.onCommand.addListener(async (c, tab) => {
  if (c === 'pick') pick(tab || await activeTab());
});
